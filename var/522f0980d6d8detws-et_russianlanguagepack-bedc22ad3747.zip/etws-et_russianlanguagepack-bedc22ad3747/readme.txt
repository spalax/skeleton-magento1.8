== Extension permanent link
Permanent link: http://shop.etwebsolutions.com/eng/et-russain-language-pack.html
Support link: http://support.etwebsolutions.com/projects/et-russain-language-pack/roadmap

== Short Description
Russian Translation for Magento CE.
Text phrases and mail templates.

== Version Compatibility
Magento CE:
1.3.х (tested in 1.3.2.4.)
1.4.x (tested in 1.4.1.1.)
1.5.x (tested in 1.5.1.0)
1.6.x (tested in 1.6.1.0.)
1.7.x (tested in 1.7.0.2.)

== Installation
* Disable compilation if it is enabled (System -> Tools -> Compilation)
* Disable cache if it is enabled (System -> Cache Management)
* Download extension or install extension from Magento Connect
* If you have downloaded it, copy all files from "install" folder to Magento root folder - where your index.php is
* Log out from admin panel
* Log in to admin panel with your login and password
* Run compilation process and enable cache if needed